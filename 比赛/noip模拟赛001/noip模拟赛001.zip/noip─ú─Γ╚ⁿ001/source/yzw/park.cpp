#include<iostream>
#include<cstring>
#define re register int
using namespace std;
int main()
{
	freopen("park.in","r",stdin);
	freopen("park.out","w",stdout);
	string s,s1;
	while(cin>>s&&s!="#")
	{
		cin>>s1;
		re len=s.length(),len1=s1.length(),cnt=0;
		re k=len-len1;
		for(re i=0;i<=k;i++)
		{
			if(s[i]==s1[0])
			{
				bool tag=1;
				for(re j=1;j<len1;j++)
				{
					if(s[i+j]^s1[j])
					{
						tag=0;
						break;
					}
				}
				if(tag)
				{
					cnt++;
					i+=len1-1;
				}
			}
		}
		cout<<cnt<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
