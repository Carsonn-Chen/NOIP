#include<cstdio>
using namespace std;
const int maxn=1005;
int f[maxn][maxn];
int main()
{
	freopen("num.in","r",stdin);
	freopen("num.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
 	f[0][0]=1;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<i;j++)
		{
			f[i][j]=(int)(((long long)(i-j)*f[i-1][j-1]+(long long)(j+1)*f[i-1][j])%2014);
		}
	}
	printf("%d\n",f[n][k]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
