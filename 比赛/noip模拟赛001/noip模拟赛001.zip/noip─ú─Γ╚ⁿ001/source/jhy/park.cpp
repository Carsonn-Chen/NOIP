#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
using namespace std;
string s1, s2;
int ans, flag;
int main() {
	freopen("park.in", "r", stdin);
	freopen("park.out", "w", stdout);
	ios::sync_with_stdio(false);
	while (1) {
		cin >> s1; ans = 0;
		if (s1.size() == 1 && s1[0] == '#') break; 
		else cin >> s2;
		int i = 0;
		while (i < (int)s1.size()) {
			if (s1[i] == s2[0]) {
				flag = 0;
				for (int j = 0; j < (int)s2.size(); j ++) {
					if (s1[i + j] != s2[j]) { flag = 1; break; } 
				} if (!flag) ans ++, i = i + (int)s2.size() - 1;
			} i ++;
		}
		cout << ans << endl;
	}
	return 0;
}
