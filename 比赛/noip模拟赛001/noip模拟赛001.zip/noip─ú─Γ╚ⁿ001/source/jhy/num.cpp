#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#define mod 2012
using namespace std;
int n, k, a[1005];
unsigned long long ans;
int main() {
	freopen("num.in", "r", stdin);
	freopen("num.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin >> n >> k; ans = 0;
	if (n == k - 1) { cout << 1 << endl; return 0; }
	for (int i = 1; i <= n; i ++) 
		a[i] = i;
	do {
		int cnt = 0; bool flag = false;
		for (int i = 1; i < n; i ++) {
			if (a[i] < a[i + 1]) cnt ++;
			if (cnt > k) { flag = 1; break; }
		}
		if (flag) continue;
		if (cnt == k) ans = (ans + 1) % mod;
	} while(next_permutation(a + 1, a + 1 + n));
	cout << ans % mod << endl;
	return 0;
}
