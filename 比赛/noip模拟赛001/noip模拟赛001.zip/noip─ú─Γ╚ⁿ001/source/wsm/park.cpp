#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("park.in","r",stdin);
	freopen("park.out","w",stdout);
	ios::sync_with_stdio(false);
	string a,b;
	while(cin>>a>>b)
	{
		int ans=0;
		while(1)
		{
			int place=a.find(b);
			if(place==-1) break; //�Ҳ����� 
			ans++; //�ҵ���һ��place 
			if(place+(int)b.size()>=(int)a.size()) break; //����ɾ���� 
			else a=a.substr(place+(int)b.size()); //ɾ���Ӷ���ǰ���
		}
		cout<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
