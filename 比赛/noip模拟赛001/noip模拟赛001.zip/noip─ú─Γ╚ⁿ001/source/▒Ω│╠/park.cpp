#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cmath>
using namespace std;
const double PI= acos(-1.0);

char a[1010],b[1010];
int next[1010],len1,len2,ans;
void pre(){ 
	memset(next,0,sizeof(next));
	ans=0; 	next[1]=0;
	int j=0;
	for(int i=2;i<=len2;i++){	
		while(j>0 && b[j+1]!=b[i]) j=next[j];
		if(b[j+1]==b[i]) j++;
		next[i]=j;
	}
}
void KMP(){
	int j=0;
	for(int i=1;i<=len1;i++){ 	
		while(j>0 && b[j+1]!=a[i]) j=next[j];
		if(b[j+1]==a[i]) j++;
		if(j==len2) ans++,j=0;  		
	}
}
int main(){ 
    freopen("park.in","r",stdin);
    freopen("park.out","w",stdout);
	scanf("%s",a+1);
	while(strcmp(a+1,"#")){	
		scanf("%s",b+1);
		len1=strlen(a+1);
		len2=strlen(b+1);
		pre(); KMP();
		printf("%d\n",ans);
		scanf("%s",a+1);
	}
}
