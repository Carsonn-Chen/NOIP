#include<iostream>
#include<string>
#include<algorithm>
#include<cstdio>
using namespace std;
#define ull unsigned long long
ull Pow[1001];
int main() {
	freopen("park.in","r",stdin);
	freopen("park.out","w",stdout);
	string s1,s2;
	ull ans = 0,now = 0;
	Pow[0] = 1;
	for(int i = 1;i <= 1000;i ++) {
		Pow[i] = Pow[i - 1] * 131;
	}
	while(cin >> s1 >> s2) {
		int l = s2.size(),l1 = s1.size();
		ans = 0,now = 0;
		long long ans1 = 0;
		for(int i = 0;i < l;i ++) {
			ans = ans * 131 + s2[i] - '0';
		}
		for(int i = 0;i < l1;i ++) {
			now = now * 131 + s1[i] - '0';
			now %= Pow[l];
			if(now == ans) {ans1 ++; now = 0;}
		}
		cout << ans1 << endl;
	}
	return 0;
}
