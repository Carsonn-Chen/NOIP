#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
unsigned long long dp[1005][1005];
int main() {
	freopen("num.in","r",stdin);
	freopen("num.out","w",stdout);
	int k,n;
	scanf("%d%d",&n,&k);
	dp[1][1] = 1;
	for(int i = 2;i <= n;i ++) {
		for(int j = 1;j <= i;j ++) {
			dp[i][j] = (dp[i-1][j] * j + dp[i-1][j - 1] * (i - j + 1)) % 2012;
		}
	}
	cout << dp[n][k+1] << endl;
	return 0;
}
